export class authentication{
  constructor(
   public userName : string,
   public password : string,
   public status : string,
   public type : boolean,
  ){}
}
